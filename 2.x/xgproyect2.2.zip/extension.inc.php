<?php // extension.inc.php

if ( !defined('INSIDE') )
{
	die("Intento de hackeo");
}

// Cambiar si la extension que usas no es .php!
$phpEx = "php";

?>
