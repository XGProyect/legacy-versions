<?php

/**
 * moonlist.php
 *
 * @version 1.0
 * @copyright 2008 by ??????? for XNova
 */

define('INSIDE'  , true);
define('INSTALL' , false);
define('IN_ADMIN', true);

$xnova_root_path = './../';
include($xnova_root_path . 'extension.inc.php');
include($xnova_root_path . 'common.' . $phpEx);

	if ($user['authlevel'] >= "2") {

		$parse = $lang;
		$query = doquery("SELECT * FROM {{table}} WHERE planet_type='3'", "planets");
		$i = 0;
		while ($u = mysql_fetch_array($query)) {
			$parse['moon'] .= "<tr>"
			. "<td class=b><center><b>" . $u[0] . "</center></b></td>"
			. "<td class=b><center><b>" . $u[1] . "</center></b></td>"
			. "<td class=b><center><b>" . $u[2] . "</center></b></td>"
			. "<td class=b><center><b>" . $u[4] . "</center></b></td>"
			. "<td class=b><center><b>" . $u[5] . "</center></b></td>"
			. "<td class=b><center><b>" . $u[6] . "</center></b></td>"
			. "</tr>";
			$i++;
		}

		if ($i == "1")
			$parse['moon'] .= "<tr><th class=b colspan=6>S�lo hay una luna</th></tr>";
		else
			$parse['moon'] .= "<tr><th class=b colspan=6>Hay {$i} lunas</th></tr>";

		display(parsetemplate(gettemplate('admin/moonlist_body'), $parse), 'Lista de Lunas' , false, '', true);
	} else {
		message ( "No tienes permisos suficientes", "�Error!");
	}
?>