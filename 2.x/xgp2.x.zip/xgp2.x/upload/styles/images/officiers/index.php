<?php
	header("location: http://".$_SERVER['SERVER_NAME']);
?>