<?php
$url=$_SERVER['SERVER_NAME'];
header("location: http://".$url);?>