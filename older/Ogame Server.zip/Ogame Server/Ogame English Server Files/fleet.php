<?php

/*
  Perberos escribio
    por ahora solo se envian flotas fantasmas. (es decir, la cantidad que
	hay en el planeta, no varia. Y cuando llegan al otro lado, Desaparecen)
	
	Corregi un pequeno bug en los tiempos que se muestran en la lista de flotas.
	
	Al enviar las flotas, solo tardan 60 segundos. pero creo que le erre en
	el sistema...
	Al parecer, fleet_start_time es para el primer arrivo... Y yo tome el fleet_end_time
	como el arrivo...
	
	El seguro contra acciones o planetas que no existen, no esta. Por ahora.
	
	PD: las flotas se agregan desde sql. en la tabla planets.
	PD2: las sondas se pueden enviar xD xD xD

*/

define('INSIDE', true);
$ugamela_root_path = './';
include($ugamela_root_path . 'extension.inc');
include($ugamela_root_path . 'common.'.$phpEx);
include('ban.php');


if(!check_user()){ header("Location: login.php"); }
//if($user['authlevel'] != 3){ message("Przebudowa","work","overview.php","3"); }


//
// Esta funcion permite cambiar el planeta actual.
//
include($ugamela_root_path . 'includes/planet_toggle.'.$phpEx);

$planetrow = doquery("SELECT * FROM {{table}} WHERE id={$user['current_planet']}",'planets',true);
$galaxyrow = doquery("SELECT * FROM {{table}} WHERE id_planet={$planetrow['id']}",'galaxy',true);
$dpath = (!$user["dpath"]) ? DEFAULT_SKINPATH : $user["dpath"];
$maxfleet = doquery("SELECT COUNT(fleet_owner) as ilosc FROM {{table}} WHERE fleet_owner='{$user['id']}'",'fleets',true);
$maxfleet_count = $maxfleet["ilosc"];
//$flota = doquery("SELECT * FROM {{table}} WHERE fleet_owner={$user['id']}",'flota',true);

check_field_current($planetrow);

includeLang('fleet');
includeLang('tech');

{//info

	$missiontype = array(
		1 => 'Attack',
		3 => 'Transport',
		4 => 'Deploy',
		5 => 'Destroy',
		6 => 'Espionage',
		8 => 'Harvest',
		9 => 'Colonize',
		);
		
	$speed = array(
		10 => 100,
		9 => 90,
		8 => 80,
		7 => 70,
		6 => 60,
		5 => 50,
		4 => 40,
		3 => 30,
		2 => 20,
		1 => 10,
		);
}



	if(!$galaxy){$galaxy = $planetrow['galaxy'];}
	if(!$system){$system = $planetrow['system'];}
	if(!$planet){$planet = $planetrow['planet'];}
	if(!$planettype){$planettype = $planetrow['planet_type'];}
	$ile = ''.++$user[$resource[108]].'';	
	$page = '<script language="JavaScript" src="scripts/flotten.js"></script>
<script language="JavaScript" src="scripts/ocnt.js"></script>
  <center>
    <table width="519" border="0" cellpadding="0" cellspacing="1">
      <tr height="20">
        <td colspan="9" class="c">Fleet (Max. '.$ile.')</td>
      </tr>
      <tr height="20">
        <th>ID</th>
        <th>Mission</th>
        <th>Ships (Total)</th>
		 <th>???</th>
        <th>Origin</th>
        <th>Depart</th>
        <th>Target</th>
        <th>Arrive</th>
        <th>Commands</th>
      </tr>';
	/*
	  Here must show the fleet movings of owner player.
	*/

	$fq = doquery("SELECT * FROM {{table}} WHERE fleet_owner={$user[id]}",'fleets');

	$i=0;
	while($f = mysql_fetch_array($fq)){
		$i++;
		
		$page .= "<tr height=20><th>$i</th><th>";
		$page .= "<a title=\"\">{$missiontype[$f[fleet_mission]]}</a>";
		$page .= "<a title=\"Flot� na planecie\">(F)</a>";
		$page .= "</th><th><a title=\"";
		/*
		  Se debe hacer una lista de las tropas
		*/
		$fleet = explode(";",$f['fleet_array']);
		$e=0;
		foreach($fleet as $a =>$b){
			if($b != ''){
				$e++;
				$a = explode(",",$b);
				$page .= "{$lang['tech']{$a[0]}}: {$a[1]}\n";
				if($e>1){$page .= "\t";}
			}
		}
		$page .= "\">{$f[fleet_amount]}</a></th>";
		$page .= "<th>".gmdate("D M d H:i:s",$f['fleet_start_hour']+2*60*60)."</th>";
		$page .= "<th>[{$f[fleet_start_galaxy]}:{$f[fleet_start_system]}:{$f[fleet_start_planet]}]</th>";
		$page .= "<th>".gmdate("D M d H:i:s",$f['fleet_start_time']+2*60*60)."</th>";
		$page .= "<th>[{$f[fleet_end_galaxy]}:{$f[fleet_end_system]}:{$f[fleet_end_planet]}]</th>";
		$page .= "<th>".gmdate("D M d H:i:s",$f['fleet_end_time']+2*60*60)."</th>";
		 $page .= " </form><th>";
     	if ($f['fleet_mess'] == 0) {
     		$page .= "     <form action=\"fleetback.php\" method=\"post\">
      <input name=\"zawracanie\" value=".$f['fleet_id']." type=hidden>
         <input value=\"Recall\" type=\"submit\">
       </form>";
     	}
            $page .= "<font color=\"lime\"><div id=\"time_0\"><font>".pretty_time(floor($f['fleet_end_time']+1-time()))."</font></div></font></th>
            </tr>";
	/*if($_POST['order_return'] = 1){	
doquery("UPDATE {{table}} SET
	`fleet_owner`='{$user['id']}',
	`fleet_mission`='4',
	`fleet_start_galaxy`='{$f[fleet_end_galaxy]}',
	`fleet_start_system`='{$f[fleet_end_system]}',
	`fleet_start_planet`='{$f[fleet_end_planet]}',
	`fleet_end_galaxy`='{$f[fleet_start_galaxy]}',
	`fleet_end_system`='{$f[fleet_start_system]}',
	`fleet_end_planet`='{$f[fleet_start_planet]}',
	`fleet_ofiara`='{$user['id']}' WHERE `fleet_id` = '{$f['fleet_id']}'" ,"fleets");}*/
		
	}

	if($i==0){$page .= "<th>-</th><th>-</th><th>-</th><th>-</th><th>-</th><th>-</th><th>-</th><th>-</th><th>-</th>";}
		 /*      <tr height="20">
			<th>2</th>
			<th> <a title="">Recolectar</a> <a title="Volver al planeta">(V)</a> </th>
			<th> <a title="Reciclador: 1">1</a></th>
			<th>[5:328:12]</th>
			<th>Thu Jun 29 1:52:13</th>
			<th>[5:328:13]</th>
			<th>Thu Jun 29 4:44:59</th>
			<th> </th>
		  </tr> */
		if($ile == $maxfleet_count){$maxflot = '<tr height="20"><th colspan="9"><font color="red">Maximum Fleet are currently being  used!</font></th></tr>';}
		$page .= '
		'.$maxflot.'</table>
	  </center>
	  <center>
		<form action="floten1.php" method="post">
		<table width="519" border="0" cellpadding="0" cellspacing="1">
		  <tr height="20">
			<td colspan="4" class="c">Please select your ships for this mission:</td>
		  </tr>
		  <tr height="20">
			<th>Ship Type</th>
			<th>Avaliable</th>';
			//<!--    <th>Gesch.</th> -->
			$page .= '
			<th>-</th>
			<th>-</th>
		  </tr>';
	if(!$planetrow){message('WTF! ERROR!','ERROR');}//uno nunca sabe xD
	/*
	  Peque?o loop para mostrar las naves que se encuentran en el planeta.
	*/
	
	foreach($reslist['fleet'] as $n => $i){
		  
		if($planetrow[$resource[$i]] > 0){
		  if($i == 202 or $i == 203 or $i == 204 or $i == 209 or $i == 210)
		{$pricelist[$i]['speed'] = $pricelist[$i]['speed']+(($pricelist[$i]['speed']*$user['combustion_tech'])*0.1);}
		  if($i == 205 or $i == 206 or $i == 208 or $i == 211)
		{$pricelist[$i]['speed'] = $pricelist[$i]['speed']+(($pricelist[$i]['speed']*$user['impulse_motor_tech'])*0.2);}
		  if($i == 207 or $i == 213 or $i == 214 or $i == 215 or $i == 216)
		{$pricelist[$i]['speed'] = $pricelist[$i]['speed']+(($pricelist[$i]['speed']*$user['hyperspace_motor_tech'])*0.3);}
			$page .= '<tr height="20">
			<th><a title="Szybko??: '.$pricelist[$i]['speed'].'">'.$lang['tech'][$i].'</a></th>
			<th>'.$planetrow[$resource[$i]].'
			  <input type="hidden" name="maxship'.$i.'" value="'.$planetrow[$resource[$i]].'"/></th>
			<!--    <th>28000 -->
			<input type="hidden" name="consumption'.$i.'" value="'.$pricelist[$i]['consumption'].'"/>
			
			<input type="hidden" name="speed'.$i.'" value="'.$pricelist[$i]['speed'].'" />
			<input type="hidden" name="galaxy" value="'.$galaxy.'"/>
			
			<input type="hidden" name="system" value="'.$system.'"/>
			<input type="hidden" name="planet" value="'.$planet.'"/>
			<input type="hidden" name="planet_type" value="'.$planettype.'"/>
			<input type="hidden" name="mission" value="'.$target_mission.'"/>
			</th>
			<input type="hidden" name="capacity'.$i.'" value="'.$pricelist[$i]['capacity'].'" />
			</th>';
			if ($i == 212){
			$page .= '<th></th><th></th></tr>';
			} else {
				$page .= '<th><a href="javascript:maxShip(\'ship'.$i.'\'); shortInfo();">max</a> </th>
				<th><input name="ship'.$i.'" size="10" value="0" onfocus="javascript:if(this.value == \'0\') this.value=\'\';" onblur="javascript:if(this.value == \'\') this.value=\'0\';" alt="'.$lang['tech'][$i].$planetrow[$resource[$i]].'"  onChange="shortInfo()" onKeyUp="shortInfo()"/></th>
				</tr>';
				$aaaaaaa = $pricelist[$i]['consumption'];
			}
			$have_ships = true;
		}

	}

	if(!$have_ships){
		/*
		  En caso de que no se tenga nunguna nave, solo se cambia el boton
		  por uno que no tenga submit, y la propiedad disabled
		*/
		$page .= '<tr height="20">
		<th colspan="4">No fleets</th>
		</tr>
		<tr height="20">
		<th colspan="4">
		<input type="button" value="Continue" enabled/></th>
		</tr>
		</table>
		</center>
		</form>';
	}
	else{
		$page .= '
		  <tr height="20">
			<th colspan="2"><a href="javascript:noShips();shortInfo();noResources();" >No ships</a></th>
			<th colspan="2"><a href="javascript:maxShips();shortInfo();" >All ships</a></th>
		  </tr>';
		  
		$przydalej = '<tr height="20"><th colspan="4"><input type="submit" value="Continue" /><br></th></tr>';
if($ile == $maxfleet_count){$przydalej = '';}
		$page .= '
		'.$przydalej.'
		<tr><th colspan="4">
		<br><center></center><br>
		</th></tr>
		</table>
	  </center>
	</form>';
	


	}
	display($page,"Flota");


// Created by Perberos. All rights reversed (C) 2006
?>