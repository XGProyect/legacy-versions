
El usuario lucky agrego:
Nave peque�a de carga: 1000
Nave grande de carga: 1000
Cazador ligero: 1000
Cazador pesado: 1000
Crucero: 1000
Nave de batalla: 1000
Colonizador: 1000
Reciclador: 1000
Sonda de espionaje: 1000
Bombardero: 1000
Sat�lite solar: 1000
Destructor: 1000
Estrella de la muerte: 1000
Acorazado: 1000
Supernova: 1000
al planeta con el ID: 1
Operaci�n realizada el: 09-12-2010 21:41:18

