
El usuario lucky agrego:
Metal: 0
Cristal: 0
Deuterio: 10000000
al planeta con el ID: 1
y Materia oscura: 0
al usuario con el ID: 0
Operaci�n realizada el: 15-08-2010 19:56:58
42
