
<font color=lime>||| SISTEMA DE SUSPENSIONES |||</font>
El usuario lucky ha suspendido al usuario lucky con las siguientes especificaciones:
Raz�n: Estoy haciendo una prueba.
el: 15-08-2010 19:43:52
hasta el: 15-08-2010 19:44:52
�En modo vacaciones? 
Operaci�n realizada el: 15-08-2010 19:43:52
