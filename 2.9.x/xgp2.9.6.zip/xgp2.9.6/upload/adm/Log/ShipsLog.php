
El usuario lucky agrego:
Nave peque�a de carga: 1000
Nave grande de carga: 1000
Cazador ligero: 1000
Cazador pesado: 1000
Crucero: 1000
Nave de batalla: 1000
Colonizador: 1000
Reciclador: 0
Sonda de espionaje: 0
Bombardero: 0
Sat�lite solar: 0
Destructor: 0
Estrella de la muerte: 0
Acorazado: 0
Supernova: 0
al planeta con el ID: 1
Operaci�n realizada el: 15-08-2010 19:59:41
 el: 27-02-2010 15:25:06
