
El usuario lucky ha cambiado los parametros de estadisticas:
Tiempo entre actualizaci�n de estad�sticas (minutos): 1
Operaci�n realizada el: 15-08-2010 20:08:38
peraci�n realizada el: 15-08-2010 19:55:09
d de flota : x1
Velocidad de producci�n : x1
Campos iniciales : 163
B�sico de metal por hora : 20
B�sico de cristal por hora : 10
B�sico de deuterio por hora : 0
�Protecci�n contra administradores activado? : 
Lenguaje : spanish
Nombre de la cookie : XGProyect
Defensas a escombros : 30%
Naves a escombros : 30%
�Protecci�n contra novatos activado? : 
Tiempo de protecci�n contra novato : 5000
Limite de puntos para la protecci�n de novato : 5
Operaci�n realizada el: 04-08-2010 08:50:06
:50
:55
