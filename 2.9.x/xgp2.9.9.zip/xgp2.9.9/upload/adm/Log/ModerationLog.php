
<font color=lime>||| SISTEMA DE MODERACI�N |||</font>
El usuario lucky modifico los siguientes datos:
Los moderadores podran ver... 
�Herramientas?:     
�Editar?:     
�Ver menu de Observaci�n?:     
�Configurar opciones de juego?:     

Los operadores podran ver... 
�Herramientas?:     
�Editar?:     
�Ver menu de Observaci�n?:     
�Configurar opciones de juego?:     
Operaci�n realizada el: 19-12-2010 16:18:17
