
El usuario lucky agrego:
Metal: 0
Cristal: 0
Deuterio: 1000000000000
al planeta con el ID: 1
y Materia oscura: 0
al usuario con el ID: 0
Operaci�n realizada el: 09-01-2011 10:53:29
