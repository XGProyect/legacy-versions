
El usuario lucky ha cambiado los parametros de estadisticas:
�La administraci�n puede figurar en el ranking?: 
Operaci�n realizada el: 09-01-2011 15:43:07
12:18
ed of game : x1
Speed Fleet : x1
Speed of production: x1
Initial fields : 163
Basic metal per hour : 20
Basic glass per hour : 10
Basic deuterium per hour : 0
Protection against active administrators? : 
Language : spanish
Cookie name : XGProyect
Defenses to rubble : 30%
Ships to rubble : 30%
Protection against activated rookie? : 
Time to protect against rookie : 5000
Limit points for the protection of rookie : 5
Operation on: 09-01-2011 09:43:15
 la protecci�n de novato : 5
Operaci�n realizada el: 09-01-2011 09:38:24
