
El usuario lucky agrego:
Mina de metal: 0
Mina de cristal: 0
Sintetizador de deuterio: 0
Planta de energ�a solar: 0
Planta de fusi�n: 0
F�brica de Robots: 0
F�brica de Nanobots: 0
Hangar: 10
Almac�n de Metal: 0
Almac�n de Cristal: 0
Contenedor de deuterio: 0
Laboratorio de investigaci�n: 0
Terraformer: 0
Dep�sito de la Alianza: 0
Silo: 0
Base lunar: 0
Phalanx: 0
Salto cu�ntico: 0
al planeta con el ID: 1
Operaci�n realizada el: 11-01-2011 12:23:15
