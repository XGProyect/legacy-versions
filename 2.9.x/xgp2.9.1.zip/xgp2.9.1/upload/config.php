<?php
if(!defined("INSIDE")){ header("location:./../"); }
$dbsettings = Array(
"server"     => "localhost", // MySQL server name.
"user"       => "root", // MySQL username.
"pass"       => "root", // MySQL password.
"name"       => "ogame", // MySQL database name.
"prefix"     => "xgp_", // Tables prefix.
"secretword" => "XGProyect1013947573"); // Cookies.
?>