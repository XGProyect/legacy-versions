<tr>
	<th><a href="game.php?page=infos&gid={fleet_id}">{fleet_name}</a> ({fleet_max} {gate_ship_dispo})</th>
	<th><input tabindex="{idx}" name="c{fleet_id}" size="13" maxlength="13" value="0" type="text"></th>
</tr>