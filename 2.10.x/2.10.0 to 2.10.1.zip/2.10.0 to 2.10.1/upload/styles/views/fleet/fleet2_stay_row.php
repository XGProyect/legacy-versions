<tr height="20">
	<td class="c" colspan="3">
		{fl_hold_time}
	</td>
</tr>
<tr height="20">
	<th colspan="3">
		<select name="{stay_type}">
			{options}
		</select>{fl_hours}
	</th>
</tr>
