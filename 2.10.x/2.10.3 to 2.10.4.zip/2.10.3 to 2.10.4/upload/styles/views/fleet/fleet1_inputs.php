<input type="hidden" name="consumption{i}" value="{consumption}" />
<input type="hidden" name="speed{i}" value="{speed}" />
<input type="hidden" name="capacity{i}" value="{capacity}" />
<input type="hidden" name="ship{i}" value="{ship}" />