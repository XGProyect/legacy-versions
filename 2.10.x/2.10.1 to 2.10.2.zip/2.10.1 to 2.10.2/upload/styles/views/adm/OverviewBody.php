<script>document.body.style.overflow = "auto";</script>
<style>table.lic{background:url(../styles/images/Adm/blank.gif);border:2px {color} solid;}
th.lic{border:0px;}</style>
<body>
<h1>{ow_title}</h1>
<table width="90%" class="lic">
<tr>
    <th class="lic">{error_message}</th>
</tr>
</table>

<br>
<table width="80%">
	<tr>
    	<td class="c">{ow_overview}</td>
    </tr>
	<tr>
    	<th height="50px"><div align="justify">{ow_welcome_text}</div></th>
    </tr>
    <tr>
        <td class="c">{ow_support}</td>
    </tr>
    <tr>
        <th>
        	<br />
            <a href="http://xgproyect.net/2-10-x-bug-report/" target="_blank">Reporte de bugs (Bug Report)</a>
        	<br />
        	<a href="http://www.xgproyect.net/" target="_blank">XG Proyect {ow_forum}</a>
        	<br />
            <br />
        </th>
    </tr>
    <tr>
    	<td class="c">{ow_credits}</td>
    </tr>
    <tr>
    	<th align="center">
            <table width="100%">
                <tr>
                  <th class="lic"><h3>{ow_proyect_leader}</h3></th>
                </tr>
                <tr>
                  <th class="lic"><h3><font color="red">lucky</font></h3></th>
                </tr>
                <tr>
                  <th class="lic"><h3>{ow_principal_contributors}</h3></th>
                </tr>
                <tr>
                  <th class="lic" align="center">
                  	<table width="100%" border="0">
                      <tr>
                        <td>
                        	angelus_ira (Estad&iacute;sticas - optimizaci&oacute;n general)<br />
                        	Calzon (Fixs varios)<br />
                        	cyberrichy (SAC's)<br />
                        	jstar (Fixs varios - optimizaci&oacute;n general)<br />
                        	Neko (Panel administrativo - Fixs varios)<br />
                        	PowerMaster (Fixs varios)<br />
                        	Think (Fixs varios)<br />
                        	zorro2666 (Fixs varios)
                        </td>
                      </tr>
                    </table>
                  </th>
                </tr>
                <tr>
                	<th class="lic"><h3>Other contributors</h3></th>
                </tr>
                <tr>
                  <th class="lic" align="center">
                  	<div align="justify">
					adri93, Alberto14, Anghelito, Arali, edering, Green, jtsamper, Kloud, medel, MSW, Neurus, Nickolay, Pada, privatethedawn, Tarta, thyphoon, tomtom, Tonique, Trojan, Saint, shoghicp, slaver7, war4head, zorro2666
					</div>
                  </th>
                </tr>
                <tr>
                  <th class="lic"><h3>{ow_special_thanks}</h3></th>
                </tr>
                <tr>
                    <th class="lic">Raito<br />Chlorel<br />e-Zobar<br />Flousedid<br /><br /></th>
                </tr>
            </table>
        </th>
    </tr>
</table>
</body>