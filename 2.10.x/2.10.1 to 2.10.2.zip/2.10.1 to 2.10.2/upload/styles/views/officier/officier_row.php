<tr>
	<td class="l">
		<img border="0" src="{dpath}gebaeude/{off_id}.jpg" align="top" width=120 height=120>
	</td>
	<td class="l">
		<strong>{off_name}</strong> ({off_status})<br>
		{off_desc}<br>
	</td>
	<td class="k">{off_link}</td>
</tr>