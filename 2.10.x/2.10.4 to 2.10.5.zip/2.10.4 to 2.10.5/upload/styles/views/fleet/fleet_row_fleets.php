<tr height="20px"> 
    <th>{num}</th> 
    <th> 
        <a>{fleet_mission}</a> 
        <a title="{tooltip}">{title}</a> 
    </th> 
    <th> 
        <a title="{fleet}">{fleet_amount}</a> 
    </th> 
    <th> 
        {fleet_start} 
    </th> 
    <th> 
        {fleet_start_time} 
    </th> 
    <th> 
        {fleet_end} 
    </th> 
    <th> 
        {fleet_end_time} 
    </th> 
    <th> 
        {fleet_arrival} 
    </th> 
    <th> 
        {inputs} 
    </th> 
</tr>